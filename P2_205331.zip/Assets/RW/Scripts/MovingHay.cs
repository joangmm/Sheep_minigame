﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovingHay : MonoBehaviour
{

    public float limitHaymov=21;
    public GameObject hayProjectile;
    public float shootInterval;
    private float shootTimer;

    void Start()
    {
        shootTimer=0;
    }

    // Update is called once per frame
    void Update()
    {
        float HInput = Input.GetAxisRaw("Horizontal");

        if (HInput < 0 && transform.position.x > -limitHaymov) 
        {
            transform.Translate(-transform.right * 10 * Time.deltaTime);
        }
        else if (HInput > 0 && transform.position.x < limitHaymov)
        {
            transform.Translate(transform.right * 10 * Time.deltaTime);
        }
        UpdateShooting();

    }
    private void ShootHay(){
        SoundManager.Instance.PlayShootClip();
        Instantiate(hayProjectile, new Vector3(transform.position.x, transform.position.y, transform.position.z-25), Quaternion.identity);
    }
    private void UpdateShooting() {
        shootTimer -= Time.deltaTime;
    if (shootTimer <= 0 && Input.GetKey(KeyCode.Space)) {
        shootTimer = shootInterval;
        ShootHay();
    }
 }

}
